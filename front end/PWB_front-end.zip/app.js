const express = require("express");
const mysql = require("mysql");
const bodyParser = require("body-parser");
const { count } = require("console");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

var CustomerID=0;
var UserID = 0;
var permissions = '';
var projects ;
var issues ;
var sl;
var pl;
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "pwb",
});

app.get("/", (req, res) => {
  UserID = 0;
  permissions = 0;
  CustomerID=0;
    res.render("login");
  });



app.post("/", (req, res) => {
  const { email, password } = req.body;
  console.error(password,email)

  connection.query(
    "SELECT UserID,`Password` FROM pwb.user WHERE UserID = (SELECT UserID FROM pwb.uemail WHERE UEmail = ?)",
    [email],
    (error, results) => {
      if (error) {
        console.error(results)
        return res.render("login");
      }
      if (password === results[0].Password) {
        console.error(results[0])
        UserID=results[0].UserID
        connection.query("select permissionID from pwb.granted where UserID= ? ;",[UserID], (error, results) => {
          if (error) throw error;
          permissions=results[0].permissionID
          console.error(results[0].permissionID,permissions)

        });
       
        connection.query("SELECT * FROM pwb.issue where IssueID = ?;",[UserID], (error, results) => {
          if (error) throw error;
          issues=results;
          sl=issues.length
          console.error(sl,'a',issues,'zz')
          connection.query("SELECT * FROM pwb.project where ProjectID = ?;",[UserID], (error, results) => {
            if (error) throw error;
            projects=results;
            pl=projects.length
            console.error(projects)
            console.error(sl,pl)
            res.render("home", { projects: projects, issues: issues ,sl:sl,pl:pl,UserID:permissions});
          });
        });
      }
       else {
        console.error("Error: Invalid email or password!");
        console.error(results[0].Password)
        res.render("login");
      }
    }
  );
});


  app.get("/customerlogin", (req, res) => {
    CustomerID=0;
    UserID = 0;
    permissions=0;
    res.render("logincust");
  });

  app.post("/custlog", (req, res) => {
    UserID = 0;
    CustomerID=0;
    permissions=0;
    const { email, Name } = req.body;
    console.error(email,Name)
    
    connection.query(
      "select lower(concat(FName,' ', LName))as name , CustomerID from pwb.customer where CustomerID = (select CustomerID from pwb.customeremail where CEmail = ?);",
      [email],
      (error, results) => {
        if (error) {
          console.error(results)
          return res.render("logincust");
        }
        if (Name === results[0].name) {
          console.error(results[0])
          CustomerID=results[0].CustomerID
          connection.query("SELECT * FROM pwb.project where ProjectID = (SELECT ProjectID FROM pwb.associated where CustomerID = ? );",[CustomerID], (error, results) => {
            if (error) throw error;
              projects=results;
              pl=projects.length
              console.error(projects)
              console.error(sl,pl)
              connection.query("SELECT * FROM pwb.issue where IssueID = (SELECT ProjectID FROM pwb.associated where CustomerID = ? );",[CustomerID], (error, results) => {
              if (error) throw error;
                issues=results;
                sl=issues.length
                console.error(sl,'f',issues,'ff')
              res.render("home", { projects: projects, issues: issues ,sl:sl,pl:pl, UserID:permissions});
  
            });
          });
        }
         else {
          console.error("Error: Invalid email or name!");
          console.error(results[0].Password)
          res.render("logincust");
        }
      }
    );
  });


  app.get('/home', (req, res) => {

    res.render("home", { projects: projects, issues: issues ,sl:sl,pl:pl,UserID:permissions});
    
  });

  app.get("/user", (req, res) => {
    res.render("add",{UserID:1})
  });



app.get("/project", (req, res) => {
    res.render("project",{UserID:permissions});
  });
app.post("/addproject", (req, res) => {
  const {  PJName, SDate, EDate, Descrpt} = req.body;
  var count = 0;
  connection.query("SELECT max(ProjectID) as p FROM pwb.project;",(error, results) => {
    if (error) throw error;
    count=results[0].p+1;
    console.error(count)
  connection.query("INSERT INTO Project (ProjectID, PJName, SDate, EDate, Descrpt)  VALUES (?, ?,?,?,?);",[count,PJName, SDate, EDate, Descrpt], (error, results) => {
    if (error) throw error;
  });
});

});

app.post("/remproject", (req, res) => {
  const {  PJName, SDate, EDate} = req.body;
  var ProjectID=0;
  connection.query("select ProjectID FROM pwb.project WHERE PJName =  ? and SDate= ? and EDate = ? ;",[ PJName, SDate, EDate], (error, results) => {
    if (error) throw error;
    ProjectID=results[0].ProjectID;
    console.error(ProjectID)
    connection.query("DELETE FROM pwb.project WHERE ProjectID = ? ;",[ ProjectID], (error, results) => {
      if (error) throw error;
      connection.query("DELETE FROM pwb.associated WHERE ProjectID = ? ;",[ ProjectID], (error, results) => {
        if (error) throw error;
        connection.query("DELETE FROM pwb.associated WHERE ProjectID = ? ;",[ ProjectID], (error, results) => {
          if (error) throw error;
          connection.query("DELETE FROM pwb.issue WHERE IssueID = ? ;",[ ProjectID], (error, results) => {
            if (error) throw error;  
            });
          });
        });
      });
    
  });
});

app.get("/cust", (req, res) => {
  res.render("addcust",{UserID:1})
});
// /------------------------------------------
app.post("/remcust", (req, res) => {
  const { FName, LName, Type, email} = req.body;
  var tcustid='';
  var pid='';
  connection.query("SELECT CustomerID FROM pwb.customer where FName =? and LName=?,Type=?;",[FName, LName, Type], (error, results) => {
    if (error) throw error;
    tcustid=results[0].CustomerID;
  connection.query(
    "delete from pwb.customer where CustomerID =?",
    [tcustid],
    (error, results) => {
      if (error) throw error ;
    }
  );
  connection.query(
    "delete from  pwb.customeremail CustomerID = ?",
    [tcustid],
    (error, results) => {
      if (error) throw error ;
    }
  );
  connection.query(
    "select  ProjectID from  pwb.associated CustomerID = ?",
    [tcustid],
    (error, results) => {
      if (error) throw error ;
      pid = results[0].ProjectID
      connection.query(
        "delete from  pwb.project ProjectID = ?",
        [pid],
        (error, results) => {
          if (error) throw error ;
          connection.query(
            "delete from  pwb.issue IssueID = ?",
            [pid],
            (error, results) => {
              if (error) throw error ;
            }
          ); 
        }
      );   
     }
  );
});
});


// --------------------------------------------------------------------------------
app.post("/addcust", (req, res) => {
  const { FName, LName, Type, email} = req.body;
  var tcustid='';
  connection.query("SELECT max(CustomerID) as c FROM pwb.customer;", (error, results) => {
    if (error) throw error;
    tcustid=results[0].c+1;
  });
  connection.query(
    "INSERT INTO pwb.customeremail (CustomerID,CEmail) VALUES (?, ?)",
    [tcustid,email],
    (error, results) => {
      if (error) throw error ;
  
  connection.query(
    "INSERT INTO pwb.customer (CustomerID, FName, LName, Type) VALUES (?, ?, ?, ?)",
    [tcustid, FName, LName, Type],
    (error, results) => {
      if (error) throw error ;
      connection.query(
        "INSERT INTO pwb.customeremail (CustomerID,CEmail) VALUES (?, ?)",
        [CustomerID,email],
        (error, results) => {
          if (error) throw error ;
        }
       );
      }
    );
  }
  );
});

app.get("/priority", (req, res) => {
  res.render("priority", { projects: projects, issues: issues ,sl:sl,pl:pl,UserID:permissions});
});
app.post('/priority', (req, res) => {
  const issue = JSON.parse(req.body.issue);
  const selectedPriority = req.body.priority;
  console.error(selectedPriority,issues[0].IssueID);
  
  connection.query(
    "UPDATE pwb.issue SET Priority = ? WHERE IssueID = ? ;",
    [selectedPriority,issues[0].IssueID],
    (error, results) => {
      if (error) throw error ;
    }
   );

  res.render("home", { projects: projects, issues: issues ,sl:sl,pl:pl,UserID:permissions});
});
app.listen(3000, () => {
  console.log("Server started on port 3000");
});
